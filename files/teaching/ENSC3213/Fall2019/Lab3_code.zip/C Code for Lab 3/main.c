/* Standard STM32L476xxx driver headers */
#include "stm32l476xx.h"

//********************************************************
// @file    main.c
// @modifier  Francisco Erivaldo Fernandes Junior
// @version V1.0
// @date    Oct-24-2018
// @note
// @brief   C code for STM32L4 Discovery Kit
// @note
//          This code is for LAB 3
//********************************************************

void Clock_Initialization(void);
void LED_Initialization(void);
void SysTick_Initialization(void);
void SysTick_Handler(void);

void delay(void);
void Toggle_RED_LED(void);
void Toggle_GREEN_LED(void);


int counter; // Global variable for timer interrupt counter

int main(void){
	Clock_Initialization();
	LED_Initialization();
	SysTick_Initialization();

	while(1){
		counter = 500;
		delay();
		Toggle_RED_LED();

		counter = 500;
		delay();
		Toggle_GREEN_LED();
	}
}

void SysTick_Handler(void) {
	counter = counter - 1;
}

void delay(void) {
	while(counter > 0) {
		// Do nothing
	}
}

void Toggle_RED_LED(void){
	GPIOB->ODR ^= 0x04; // XOR (Exclusive-OR) --> ^=
}

void Toggle_GREEN_LED(void){
	GPIOE->ODR ^= 0x100; // XOR --> ^=
}

void Clock_Initialization(void){
	RCC->CR |= RCC_CR_MSION;

	// Select MSI as the clock source of System Clock
	RCC->CFGR &= ~RCC_CFGR_SW;

	// Wait until MSI is ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);

	// MSIRANGE can be modified when MSI is OFF (MSION=0) or when MSI is ready (MSIRDY=1).
	RCC->CR &= ~RCC_CR_MSIRANGE;
	RCC->CR |= RCC_CR_MSIRANGE_7;  // Select MSI 8 MHz

	// The MSIRGSEL bit in RCC-CR select which MSIRANGE is used.
	// If MSIRGSEL is 0, the MSIRANGE in RCC_CSR is used to select the MSI clock range.  (This is the default)
	// If MSIRGSEL is 1, the MSIRANGE in RCC_CR is used.
	RCC->CR |= RCC_CR_MSIRGSEL;

	// Enable MSI and wait until it's ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);
}

void LED_Initialization(void){
		/* 1st) Enable GPIOs ports B and E */
		RCC->AHB2ENR |= 0x12;

		/**********************************************************************************************/
		/* Pin Initialization for Red LED (PB 2) */

		/* 2nd) Configure PB 2 as Output

			To do this, you will have to modify the GPIOB_MODER register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOB_MODER, as follows:
			MODER:	00: Input mode, 01: General purpose output mode
		       		10: Alternate function mode, 11: Analog mode
		*/

		GPIOB->MODER &= ~(0x30);
		GPIOB->MODER |= 0x10;

		/* 3rd) Configure PB 2 Output Type as Push-Pull

			To do this, you will have to modify the GPIOB_OTYPER register.
			Each pin in a GPIO port is controlled by ONE bit in the GPIOB_OTYPER, as follows:
			OTYPER:	0: Output push-pull
		       		1: Output open-drain
		*/

		GPIOB->OTYPER &= ~(0x04);

		/* 4th) Configure PB 2 Output Type as No Pull-up No Pull-down

			To do this, you will have to modify the GPIOB_PUPDR register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOB_PUPDR, as follows:
			PUPDR:	00: No Pull-up No Pull-down,	01: Pull-up
		       		10: Pull-down,					11: Reserved
		*/

		GPIOB->PUPDR &= ~(0x30);

		/******************************************************************************************/


		/* Pin Initialization for GREEN LED (PE 8) */

		/* 5th) Configure PE 8 as Output

			To do this, you will have to modify the GPIOE_MODER register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOE_MODER, as follows:
			MODER:	00: Input mode, 01: General purpose output mode
		       		10: Alternate function mode, 11: Analog mode
		*/

		GPIOE->MODER &= ~(0x30000);
		GPIOE->MODER |= 0x10000;

		/* 6th) Configure PE 8 Output Type as Push-Pull

			To do this, you will have to modify the GPIOE_OTYPER register.
			Each pin in a GPIO port is controlled by ONE bit in the GPIOE_OTYPER, as follows:
			OTYPER:	0: Output push-pull
		       		1: Output open-drain
		*/

		GPIOE->OTYPER &= ~(0x100);

		/* 7th) Configure PE 8 Output Type as No Pull-up No Pull-down

			To do this, you will have to modify the GPIOE_PUPDR register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOE_PUPDR, as follows:
			PUPDR:	00: No Pull-up No Pull-down,	01: Pull-up
		       		10: Pull-down,					11: Reserved
		*/

		GPIOE->PUPDR &= ~(0x30000);
}

void SysTick_Initialization(void){
	// 1st) Set SysTick control and status register (SysTick_CTRL) to DISABLE SysTick IRQ
		//		 and SysTick timer.

		// Disable SysTick counter (clear BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x01);

		// Disable SysTick interrupt request (clear BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x02);

		// Select External clock as the clock source of the SysTick interrupt
		// (clear BIT 2 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x04);

		// 2nd) Set SysTick reload value register (SysTick_LOAD) and
		//		 specify the number of ticks between two interrupts.
		SysTick->LOAD = 999;

		// 3rd) Clear SysTick current value register (SysTick_VAL).
		SysTick->VAL = 0;

		// 4th) Set up the interrupt priority by programming the SHPR3 register.
		// You don't need to change anything in the following block of code.
		NVIC_SetPriority(SysTick_IRQn, (1<<__NVIC_PRIO_BITS) - 1 );

		// 5th) ENABLE SysTick interrupt by setting the TICKINT bit (SysTick_CTRL)

		// Enable SysTick interrupt request (SET BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x02;

		// 6th)  ENABLE SysTick IRQ and SysTick timer.

		// Enable SysTick counter (SET BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x01;
}
