/* Standard STM32L476xxx driver headers */
#include "stm32l476xx.h"

//********************************************************
// @file    main.c
// @modifier  Francisco Erivaldo Fernandes Junior
// @version V3.0
// @date    Oct-18-2018
// @note    
// @brief   C code for STM32L4 Discovery Kit
// @note
//          This code is for LAB 1
//********************************************************

void GPIO_Clock_Enable(){
	// Enable GPIO A, B and E
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; 
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN; 
}

void GPIO_Pin_Init(){
	// Configure PA0 (Center), PA1 (Left), PA2 (Right), PA3 (Up), and PA5 (Down) as Input
	GPIOA->MODER &= ~GPIO_MODER_MODE0; // Clear GPIOA_MODER bits 0 and 1 (PA0 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE1; // Clear GPIOA_MODER bits 3 and 2 (PA1 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE2; // Clear GPIOA_MODER bits 5 and 4 (PA2 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE3; // Clear GPIOA_MODER bits 7 and 6 (PA3 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE5; // Clear GPIOA_MODER bits 11 and 10 (PA5 as input)
	
	// Configure PA0 (Center), PA1 (Left), PA2 (Right), PA3 (Up), and PA5 (Down) as Pull-down
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD0_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD1;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD1_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD2;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD2_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD3;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD3_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD5_1;
	
	// Configure PB2 (Red LED) as Output
	GPIOB->MODER &= ~GPIO_MODER_MODE2;
	GPIOB->MODER |= GPIO_MODER_MODE2_0;
	
	// Configure PE8 (Green LED) as Output
	GPIOE->MODER &= ~GPIO_MODER_MODE8;
	GPIOE->MODER |= GPIO_MODER_MODE8_0;
	
	// Configure PB2 (Red LED) Output Type as Push-Pull
	GPIOB->OTYPER &= ~GPIO_OTYPER_OT2;
	
	// Configure PE8 (Green LED) Output Type as Push-Pull
	GPIOE->OTYPER &= ~GPIO_OTYPER_OT8;
	
	// Set the speed for PB2 and PE8 as low
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED2;
	GPIOE->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED8;
	
	// Configure PB2 (Red LED) Output Type as No Pull-up No Pull-down
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD2;
	
	// Configure PE8 (Green LED) Output Type as No Pull-up No Pull-down
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD8;
}

//******************************************************************************************
//* The main program starts here
//******************************************************************************************

int main(void) {
	GPIO_Clock_Enable();
	
	GPIO_Pin_Init();
	
	// Begin infinite loop
	while(1) {
		// Set both LEDs to on when up button is pushed
		// Toggle both LEDs when middle button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID0) != 0x00){
			GPIOE->ODR ^= GPIO_ODR_ODR_8;
			GPIOB->ODR ^= GPIO_ODR_ODR_2;
			while((GPIOA->IDR & GPIO_IDR_ID0) != 0x00);
		}
		
		// Toggle red LED when right button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID2) != 0x00){
			GPIOB->ODR ^= GPIO_ODR_ODR_2;
			while((GPIOA->IDR & GPIO_IDR_ID2) != 0x00);
		}
		
		// Toggle green LED when left button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID1) != 0x00){
			GPIOE->ODR ^= GPIO_ODR_ODR_8;
			while((GPIOA->IDR & GPIO_IDR_ID1) != 0x00);
		}
		
		// Set both LEDs to on when up button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID3) != 0x00){
			GPIOE->ODR |= 0x100;
			GPIOB->ODR |= 0x04;
			while((GPIOA->IDR & GPIO_IDR_ID3) != 0x00);
		}
		
		// Set both LEDs to off when down button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID5) != 0x00){
			GPIOE->ODR &= ~0x100;
			GPIOB->ODR &= ~0x04;
			while((GPIOA->IDR & GPIO_IDR_ID5) != 0x00);
		}
	}
}
 
