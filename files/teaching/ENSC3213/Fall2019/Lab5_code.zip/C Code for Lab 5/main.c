/* Standard STM32L476xxx driver headers */
#include "stm32l476xx.h"

//********************************************************
// @file    main.c
// @modifier  Francisco Erivaldo Fernandes Junior
// @version V1.0
// @date    Oct-28-2018
// @note
// @brief   C code for STM32L4 Discovery Kit
// @note
//          This code is for LAB 5
//********************************************************

void Clock_Initialization(void);
void GPIO_Initialization(void);
void SysTick_Initialization(void);
void SysTick_Handler(void);

void delay(void);

int counter; // Global variable for timer interrupt counter

int main(void){
	Clock_Initialization();
	GPIO_Initialization();
	SysTick_Initialization();

	uint32_t FullStep[4] = {0x44, 0x84, 0x88, 0x48};

	int i, j;
	for(i = 0; i < 512; i++){
		for(j = 0; j < 4; j++){
			counter = 3;
			delay(); // delay three mseconds
			GPIOB->ODR &= ~(0xCC);
			GPIOB->ODR |= FullStep[j];
		}
	}

	while(1); // Dead Loop
}

void SysTick_Handler(void) {
	counter = counter - 1;
}

void delay(void) {
	while(counter > 0) {
		// Do nothing
	}
}

void GPIO_Initialization(void){
		/* Enable GPIO ports B */
		RCC->AHB2ENR |= 0x02;

		/**********************************************************************************************/
		/* Pin Initialization for the stepper motor */

		/* 1st) Configure PB2, PB3, PB6, PB7 as output

			To do this, you will have to modify the GPIOB_MODER register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOB_MODER, as follows:
			MODER:	00: Input mode, 01: General purpose output mode
					10: Alternate function mode, 11: Analog mode
		*/

		GPIOB->MODER &= ~(0xA0A0);
		GPIOB->MODER |= 0x5050;

		/* 2nd) Configure PB2, PB3, PB6, PB7 as Push-Pull

		To do this, you will have to modify the GPIOB_OTYPER register.
		Each pin in a GPIO port is controlled by ONE bit in the GPIOB_OTYPER, as follows:
		OTYPER:	0: Output push-pull
	       		1: Output open-drain
		*/

		GPIOB->OTYPER &= ~(0xCC);

		/* 3rd) Configure PB2, PB3, PB6, PB7 as No Pull-up No Pull-down

				To do this, you will have to modify the GPIOB_PUPDR register.
				Each pin in a GPIO port is controlled by TWO bits in the GPIOB_PUPDR, as follows:
				PUPDR:	00: No Pull-up No Pull-down,	01: Pull-up
			       		10: Pull-down,					11: Reserved
		*/

		GPIOB->PUPDR &= ~(0xCC);
}

void SysTick_Initialization(void){
	// 1st) Set SysTick control and status register (SysTick_CTRL) to DISABLE SysTick IRQ
		//		 and SysTick timer.

		// Disable SysTick counter (clear BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x01);

		// Disable SysTick interrupt request (clear BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x02);

		// Select External clock as the clock source of the SysTick interrupt
		// (clear BIT 2 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x04);

		// 2nd) Set SysTick reload value register (SysTick_LOAD) and
		//		 specify the number of ticks between two interrupts.
		SysTick->LOAD = 999;

		// 3rd) Clear SysTick current value register (SysTick_VAL).
		SysTick->VAL = 0;

		// 4th) Set up the interrupt priority by programming the SHPR3 register.
		// You don't need to change anything in the following block of code.
		NVIC_SetPriority(SysTick_IRQn, (1<<__NVIC_PRIO_BITS) - 1 );

		// 5th) ENABLE SysTick interrupt by setting the TICKINT bit (SysTick_CTRL)

		// Enable SysTick interrupt request (SET BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x02;

		// 6th)  ENABLE SysTick IRQ and SysTick timer.

		// Enable SysTick counter (SET BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x01;
}

void Clock_Initialization(void){
	RCC->CR |= RCC_CR_MSION;

	// Select MSI as the clock source of System Clock
	RCC->CFGR &= ~RCC_CFGR_SW;

	// Wait until MSI is ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);

	// MSIRANGE can be modified when MSI is OFF (MSION=0) or when MSI is ready (MSIRDY=1).
	RCC->CR &= ~RCC_CR_MSIRANGE;
	RCC->CR |= RCC_CR_MSIRANGE_7;  // Select MSI 8 MHz

	// The MSIRGSEL bit in RCC-CR select which MSIRANGE is used.
	// If MSIRGSEL is 0, the MSIRANGE in RCC_CSR is used to select the MSI clock range.  (This is the default)
	// If MSIRGSEL is 1, the MSIRANGE in RCC_CR is used.
	RCC->CR |= RCC_CR_MSIRGSEL;

	// Enable MSI and wait until it's ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);
}
