/* Standard STM32L476xxx driver headers */
#include "stm32l476xx.h"

//********************************************************
// @file    main.c
// @modifier  Francisco Erivaldo Fernandes Junior
// @version V1.0
// @date    Oct-28-2018
// @note
// @brief   C code for STM32L4 Discovery Kit
// @note
//          This code is for LAB 5
//********************************************************

#include "LCD.h"

void Clock_Initialization(void);
void GPIO_Initialization(void);
void SysTick_Initialization(void);
void SysTick_Handler(void);

void Keypad_Initialization();
unsigned char keypad_scan(void);
void delay(void);

int counter; // Global variable for timer interrupt counter

int main(void){
	Clock_Initialization();
	LCD_Initialization();
	SysTick_Initialization();
	Keypad_Initialization();

	// LCD_DisplayString() can display any string in the LCD display
	// Use the syntax below to use this function:
	// 		LCD_DisplayString((uint8_t*)"MMMMMM");

	char str[1];

	while(1){
		str[0] = keypad_scan();
		LCD_DisplayString((uint8_t*)str);
	}
}

void SysTick_Handler(void) {
	counter = counter - 1;
}

unsigned char keypad_scan(void) {
	unsigned char row, col;
		unsigned char key;

		unsigned char keymap[4][4] = {
			{'1','2','3','A'},
			{'4','5','6','B'},
			{'7','8','9','C'},
			{'*','0','#','D'}
		};

		uint32_t inputMask  = GPIO_IDR_ID1 | GPIO_IDR_ID2 | GPIO_IDR_ID3 | GPIO_IDR_ID5;
		uint32_t outputs[4] = {GPIO_ODR_OD10, GPIO_ODR_OD11, GPIO_ODR_OD12, GPIO_ODR_OD13};
		uint32_t inputs[4]  = {GPIO_IDR_ID1, GPIO_IDR_ID2, GPIO_IDR_ID3, GPIO_IDR_ID5};

		GPIOE->ODR = 0;

		counter = 3;
		delay(); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5

		while( (GPIOA->IDR & inputMask) == inputMask){;}  // Wait until key pressed

		for(row = 0; row < 4; row++){ // Row scan
			GPIOE->ODR |= (GPIO_ODR_OD10 | GPIO_ODR_OD11 | GPIO_ODR_OD12 | GPIO_ODR_OD13);
			GPIOE->ODR &= ~outputs[row];

			counter = 3;
			delay(); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5

			for(col = 0; col < 4; col++){// Column scan
				if((GPIOA->IDR & inputs[col]) == 0 ){
					key = keymap[row][col];
					while( (GPIOA->IDR & inputMask) != inputMask){;} // Wait until key released
					return key;
				}
			}
		}

		return 0xFF;
}

void delay(void) {
	while(counter > 0) {
		// Do nothing
	}
}

void GPIO_Initialization(void){
		/* Enable GPIO ports B */
		RCC->AHB2ENR |= 0x02;

		/**********************************************************************************************/
		/* Pin Initialization for the stepper motor */

		/* 1st) Configure PB2, PB3, PB6, PB7 as output

			To do this, you will have to modify the GPIOB_MODER register.
			Each pin in a GPIO port is controlled by TWO bits in the GPIOB_MODER, as follows:
			MODER:	00: Input mode, 01: General purpose output mode
					10: Alternate function mode, 11: Analog mode
		*/

		GPIOB->MODER &= ~(0xA0A0);
		GPIOB->MODER |= 0x5050;

		/* 2nd) Configure PB2, PB3, PB6, PB7 as Push-Pull

		To do this, you will have to modify the GPIOB_OTYPER register.
		Each pin in a GPIO port is controlled by ONE bit in the GPIOB_OTYPER, as follows:
		OTYPER:	0: Output push-pull
	       		1: Output open-drain
		*/

		GPIOB->OTYPER &= ~(0xCC);

		/* 3rd) Configure PB2, PB3, PB6, PB7 as No Pull-up No Pull-down

				To do this, you will have to modify the GPIOB_PUPDR register.
				Each pin in a GPIO port is controlled by TWO bits in the GPIOB_PUPDR, as follows:
				PUPDR:	00: No Pull-up No Pull-down,	01: Pull-up
			       		10: Pull-down,					11: Reserved
		*/

		GPIOB->PUPDR &= ~(0xCC);
}

void Keypad_Initialization(void){
	/* Beginning of Keypad Hardware Initialization */
	// Enable GPIOs A and E
	RCC->AHB2ENR |= 0x11;

	// Setting PA 1, 2, 3, 5 as GPIO input
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOA->MODER &= ~(0xCFC);

	// Setting PE 10, 11, 12, 13 as GPIO output
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOE->MODER &= ~(0x0FF00000);
	GPIOE->MODER |= 0x05500000;

	// Setting PE10, PE11, PE12, PE13 as open-drain
	// GPIO Output Type: Output push-pull (0, reset), Output open drain (1)
	GPIOE->OTYPER |= 0x3C00;
}

void SysTick_Initialization(void){
	// 1st) Set SysTick control and status register (SysTick_CTRL) to DISABLE SysTick IRQ
		//		 and SysTick timer.

		// Disable SysTick counter (clear BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x01);

		// Disable SysTick interrupt request (clear BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x02);

		// Select External clock as the clock source of the SysTick interrupt
		// (clear BIT 2 of the SysTick_CTRL register)
		SysTick->CTRL &= ~(0x04);

		// 2nd) Set SysTick reload value register (SysTick_LOAD) and
		//		 specify the number of ticks between two interrupts.
		SysTick->LOAD = 999;

		// 3rd) Clear SysTick current value register (SysTick_VAL).
		SysTick->VAL = 0;

		// 4th) Set up the interrupt priority by programming the SHPR3 register.
		// You don't need to change anything in the following block of code.
		NVIC_SetPriority(SysTick_IRQn, (1<<__NVIC_PRIO_BITS) - 1 );

		// 5th) ENABLE SysTick interrupt by setting the TICKINT bit (SysTick_CTRL)

		// Enable SysTick interrupt request (SET BIT 1 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x02;

		// 6th)  ENABLE SysTick IRQ and SysTick timer.

		// Enable SysTick counter (SET BIT 0 of the SysTick_CTRL register)
		SysTick->CTRL |= 0x01;
}

void Clock_Initialization(void){
	RCC->CR |= RCC_CR_MSION;

	// Select MSI as the clock source of System Clock
	RCC->CFGR &= ~RCC_CFGR_SW;

	// Wait until MSI is ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);

	// MSIRANGE can be modified when MSI is OFF (MSION=0) or when MSI is ready (MSIRDY=1).
	RCC->CR &= ~RCC_CR_MSIRANGE;
	RCC->CR |= RCC_CR_MSIRANGE_7;  // Select MSI 8 MHz

	// The MSIRGSEL bit in RCC-CR select which MSIRANGE is used.
	// If MSIRGSEL is 0, the MSIRANGE in RCC_CSR is used to select the MSI clock range.  (This is the default)
	// If MSIRGSEL is 1, the MSIRANGE in RCC_CR is used.
	RCC->CR |= RCC_CR_MSIRGSEL;

	// Enable MSI and wait until it's ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0);
}
