#include <stdint.h>

#define __IO volatile

typedef struct
{
  __IO uint32_t CR;          /*!< LCD control register,              Address offset: 0x00 */
  __IO uint32_t FCR;         /*!< LCD frame control register,        Address offset: 0x04 */
  __IO uint32_t SR;          /*!< LCD status register,               Address offset: 0x08 */
  __IO uint32_t CLR;         /*!< LCD clear register,                Address offset: 0x0C */
  uint32_t RESERVED;         /*!< Reserved,                          Address offset: 0x10 */
  __IO uint32_t RAM[16];     /*!< LCD display memory,           Address offset: 0x14-0x50 */
} LCD_TypeDef;

#define PERIPH_BASE           ((uint32_t)0x40000000U) /*!< Peripheral base address */
#define APB1PERIPH_BASE        PERIPH_BASE
#define LCD_BASE              (APB1PERIPH_BASE + 0x2400U)
#define LCD                 ((LCD_TypeDef *) LCD_BASE)

#define LCD_SR_UDR                 ((uint32_t)0x00000004U)     /*!< Update Display Request Bit */

/* Constant table for cap characters 'A' --> 'Z' */
const uint16_t CapLetterMap[26] = {
        /* A      B      C      D      E      F      G      H      I  */
        0xFE00,0x6714,0x1d00,0x4714,0x9d00,0x9c00,0x3f00,0xfa00,0x0014,
        /* J      K      L      M      N      O      P      Q      R  */
        0x5300,0x9841,0x1900,0x5a48,0x5a09,0x5f00,0xFC00,0x5F01,0xFC01,
        /* S      T      U      V      W      X      Y      Z  */
        0xAF00,0x0414,0x5b00,0x18c0,0x5a81,0x00c9,0x0058,0x05c0
};

/* Constant table for cap characters '0' --> '9' */
const uint16_t Numbers[26] = {
        /* 0      1      2      3      4      5  */
        0x5F00,0x4200,0xF500,0x6700,0xEA00,0xAF00,
		/* 6      7      8      9 */
		0xBF00,0x4600,0xFF00,0xEF00
};

// This is the function you need to complete for the second objective
void LCD_WritePosition(char ch, uint8_t position){
	uint16_t encoding;
	uint8_t offset, i;
	uint8_t C[4];

	// Clear all display...

	// Wait until LCD ready
	while ((LCD->SR & LCD_SR_UDR) != 0);

	for (i = 0; i <= 15; i++) {
		LCD->RAM[i] = 0;
	}

	// Update the LCD display
	LCD->SR |= LCD_SR_UDR;

	if ( (ch < 0x5B) && (ch > 0x40) )
	{
		encoding = CapLetterMap[ch - 'A'];
	}

	if ( (ch < 0x3A) && (ch > 0x2F) )
	{
			encoding = Numbers[ch - 0x30];
	}

	for (offset = 12, i = 0; i < 4; offset -= 4, i++) {
		C[i] = (encoding >> offset) & 0x0F;
	}

	// Wait until LCD is ready
	while ((LCD->SR & LCD_SR_UDR) != 0); // Wait for Update Display Request Bit

	if (position == 0) {
		/* Position 1 on LCD (digit1)*/
		// Clear all pixels in Position 1
		LCD->RAM[0] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
		LCD->RAM[2] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
		LCD->RAM[4] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
		LCD->RAM[6] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );

		/* 1G 1B 1M 1E */
		LCD->RAM[0] |= ((C[0] & 0x1) << 4) | (((C[0] & 0x2) >> 1) << 23) | (((C[0] & 0x4) >> 2) << 22) | (((C[0] & 0x8) >> 3) << 3);
		/* 1F 1A 1C 1D  */
		LCD->RAM[2] |= ((C[1] & 0x1) << 4) | (((C[1] & 0x2) >> 1) << 23) | (((C[1] & 0x4) >> 2) << 22) | (((C[1] & 0x8) >> 3) << 3);
		/* 1Q 1K 1Col 1P  */
		LCD->RAM[4] |= ((C[2] & 0x1) << 4) | (((C[2] & 0x2) >> 1) << 23) | (((C[2] & 0x4) >> 2) << 22) | (((C[2] & 0x8) >> 3) << 3);
		/* 1H 1J 1DP 1N  */
		LCD->RAM[6] |= ((C[3] & 0x1) << 4) | (((C[3] & 0x2) >> 1) << 23) | (((C[3] & 0x4) >> 2) << 22) | (((C[3] & 0x8) >> 3) << 3);
	}
	if (position == 1) {
		/* Position 2 on LCD (digit2)*/
		LCD->RAM[0] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
		LCD->RAM[2] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
		LCD->RAM[4] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
		LCD->RAM[6] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
		/* 2G 2B 2M 2E */
		LCD->RAM[0] |= ((C[0] & 0x1) << 6) | (((C[0] & 0x2) >> 1) << 13) | (((C[0] & 0x4) >> 2) << 12) | (((C[0] & 0x8) >> 3) << 5);
		/* 2F 2A 2C 2D  */
		LCD->RAM[2] |= ((C[1] & 0x1) << 6) | (((C[1] & 0x2) >> 1) << 13) | (((C[1] & 0x4) >> 2) << 12) | (((C[1] & 0x8) >> 3) << 5);
		/* 2Q 2K 2Col 2P  */
		LCD->RAM[4] |= ((C[2] & 0x1) << 6) | (((C[2] & 0x2) >> 1) << 13) | (((C[2] & 0x4) >> 2) << 12) | (((C[2] & 0x8) >> 3) << 5);
		/* 2H 2J 2DP 2N  */
		LCD->RAM[6] |= ((C[3] & 0x1) << 6) | (((C[3] & 0x2) >> 1) << 13) | (((C[3] & 0x4) >> 2) << 12) | (((C[3] & 0x8) >> 3) << 5);
	}

		/* Position 3 on LCD (digit3)*/
	if (position == 2) {
		LCD->RAM[0] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
		LCD->RAM[2] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
		LCD->RAM[4] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
		LCD->RAM[6] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
		/* 3G 3B 3M 3E */
		LCD->RAM[0] |= ((C[0] & 0x1) << 15) | (((C[0] & 0x2) >> 1) << 29) | (((C[0] & 0x4) >> 2) << 28) | (((C[0] & 0x8) >> 3) << 14);
		/* 3F 3A 3C 3D */
		LCD->RAM[2] |= ((C[1] & 0x1) << 15) | (((C[1] & 0x2) >> 1) << 29) | (((C[1] & 0x4) >> 2) << 28) | (((C[1] & 0x8) >> 3) << 14);
		/* 3Q 3K 3Col 3P  */
		LCD->RAM[4] |= ((C[2] & 0x1) << 15) | (((C[2] & 0x2) >> 1) << 29) | (((C[2] & 0x4) >> 2) << 28) | (((C[2] & 0x8) >> 3) << 14);
		/* 3H 3J 3DP  3N  */
		LCD->RAM[6] |= ((C[3] & 0x1) << 15) | (((C[3] & 0x2) >> 1) << 29) | (((C[3] & 0x4) >> 2) << 28) | (((C[3] & 0x8) >> 3) << 14);
	}
	if (position == 3) {
		/* Position 4 on LCD (digit4)*/
		LCD->RAM[0] &= ~( 1U << 31 | 1U << 30);
		LCD->RAM[1] &= ~( 1U << 1 | 1U << 0 );
		LCD->RAM[2] &= ~( 1U << 31 | 1U << 30);
		LCD->RAM[3] &= ~( 1U << 1 | 1U << 0 );
		LCD->RAM[4] &= ~( 1U << 31 | 1U << 30);
		LCD->RAM[5] &= ~( 1U << 1 | 1U << 0 );
		LCD->RAM[6] &= ~( 1U << 31 | 1U << 30);
		LCD->RAM[7] &= ~( 1U << 1 | 1U << 0 );
		/* 4G 4B 4M 4E */
		LCD->RAM[0] |= ((C[0] & 0x1) << 31) | (((C[0] & 0x8) >> 3) << 30);
		LCD->RAM[1] |= (((C[0] & 0x2) >> 1) << 1) | (((C[0] & 0x4) >> 2) << 0);
		/* 4F 4A 4C 4D */
		LCD->RAM[2] |= ((C[1] & 0x1) << 31) | (((C[1] & 0x8) >> 3) << 30);
		LCD->RAM[3] |= (((C[1] & 0x2) >> 1) << 1) | (((C[1] & 0x4) >> 2) << 0);
		/* 4Q 4K 4Col 4P  */
		LCD->RAM[4] |= ((C[2] & 0x1) << 31) | (((C[2] & 0x8) >> 3) << 30);
		LCD->RAM[5] |= (((C[2] & 0x2) >> 1) << 1) | (((C[2] & 0x4) >> 2) << 0);
		/* 4H 4J 4DP  4N  */
		LCD->RAM[6] |= ((C[3] & 0x1) << 31) | (((C[3] & 0x8) >> 3) << 30);
		LCD->RAM[7] |= (((C[3] & 0x2) >> 1) << 1) | (((C[3] & 0x4) >> 2) << 0);
	}
	if (position == 4) {
		/* Position 5 on LCD (digit5)*/
		LCD->RAM[0] &= ~( 1U << 25 | 1U << 24);
		LCD->RAM[1] &= ~( 1U << 3 | 1U << 2 );
		LCD->RAM[2] &= ~( 1U << 25 | 1U << 24);
		LCD->RAM[3] &= ~( 1U << 3 | 1U << 2 );
		LCD->RAM[4] &= ~( 1U << 25 | 1U << 24 );
		LCD->RAM[5] &= ~( 1U << 3 | 1U << 2 );
		LCD->RAM[6] &= ~( 1U << 25 | 1U << 24 );
		LCD->RAM[7] &= ~( 1U << 3 | 1U << 2 );
		/* 5G 5B 5M 5E */
		LCD->RAM[0] |= (((C[0] & 0x2) >> 1) << 25) | (((C[0] & 0x4) >> 2) << 24);
		LCD->RAM[1] |= ((C[0] & 0x1) << 3) | (((C[0] & 0x8) >> 3) << 2);
		/* 5F 5A 5C 5D */
		LCD->RAM[2] |= (((C[1] & 0x2) >> 1) << 25) | (((C[1] & 0x4) >> 2) << 24);
		LCD->RAM[3] |= ((C[1] & 0x1) << 3) | (((C[1] & 0x8) >> 3) << 2);
		/* 5Q 5K 5Col 5P  */
		LCD->RAM[4] |= (((C[2] & 0x2) >> 1) << 25) | (((C[2] & 0x4) >> 2) << 24);
		LCD->RAM[5] |= ((C[2] & 0x1) << 3) | (((C[2] & 0x8) >> 3) << 2);
		/* 5H 5J 5DP  5N  */
		LCD->RAM[6] |= (((C[3] & 0x2) >> 1) << 25) | (((C[3] & 0x4) >> 2) << 24);
		LCD->RAM[7] |= ((C[3] & 0x1) << 3) | (((C[3] & 0x8) >> 3) << 2);
	}
	if (position == 5) {
		/* Position 6 on LCD (digit6)*/
		LCD->RAM[0] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
		LCD->RAM[2] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
		LCD->RAM[4] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
		LCD->RAM[6] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
		/* 6G 6B 6M 6E */
		LCD->RAM[0] |= ((C[0] & 0x1) << 17) | (((C[0] & 0x2) >> 1) << 8) | (((C[0] & 0x4) >> 2) << 9) | (((C[0] & 0x8) >> 3) << 26);
		/* 6F 6A 6C 6D */
		LCD->RAM[2] |= ((C[1] & 0x1) << 17) | (((C[1] & 0x2) >> 1) << 8) | (((C[1] & 0x4) >> 2) << 9) | (((C[1] & 0x8) >> 3) << 26);
		/* 6Q 6K 6Col 6P  */
		LCD->RAM[4] |= ((C[2] & 0x1) << 17) | (((C[2] & 0x2) >> 1) << 8) | (((C[2] & 0x4) >> 2) << 9) | (((C[2] & 0x8) >> 3) << 26);
		/* 6H 6J 6DP  6N  */
		LCD->RAM[6] |= ((C[3] & 0x1) << 17) | (((C[3] & 0x2) >> 1) << 8) | (((C[3] & 0x4) >> 2) << 9) | (((C[3] & 0x8) >> 3) << 26);
	}

	LCD->SR |= LCD_SR_UDR;
}
