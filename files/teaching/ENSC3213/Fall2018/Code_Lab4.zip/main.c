#include "stm32l476xx.h"
#include "SysClock.h"

unsigned char FullStep[4] = {0xa, 0x9, 0x5, 0x6};
unsigned char HalfStep[8] = {0x1, 0x3, 0x2, 0x6, 0x4, 0xC, 0x8, 0x9};

// Four pins to control the stepper motor: PB 2, PB 3, PB 6, and PB 7
#define PIN1 2  //A
#define PIN2 3  // A-
#define PIN3 6  // B
#define PIN4 7  // B-

// Counter-clock-wise 
// 1000, 1100, 0100, 0110, 0010, 0011, 0001, 1001
// Clockwise
// 0001, 0011, 0010, 0110, 0100, 1100, 1000, 1001

void waitms(unsigned int ms){
	int i, j;
	for(i = 0; i < ms; i++){
		for(j=0; j < 4000; j++);
	}	
}

void Half_Stepping_CounterClockwise(void){
	int i, j;
	uint32_t output;
	for(i = 0; i < 8; i++){	
		  waitms(6);
			output = GPIOB->ODR;
			output &= ~( 1<< PIN1 | 1 << PIN2 | 1 << PIN3 | 1<< PIN4 );			
			output |= ((HalfStep[i] & 0x8) >> 3) << PIN1;
			output |= ((HalfStep[i] & 0x4) >> 2) << PIN2;
			output |= ((HalfStep[i] & 0x2) >> 1) << PIN3;
			output |= ( HalfStep[i] & 0x1) << PIN4;
			GPIOB->ODR = output; 
	}
}

void Full_Stepping(void){
	int i, j;
	uint32_t output;
	unsigned char FullStep[4] = {0xa, 0x9, 0x5, 0x6};
	for(i = 0; i < 4; i++){	
			waitms(15);
			output = GPIOB->ODR;
			output &= ~( 1<< PIN1 | 1 << PIN2 | 1 << PIN3 | 1<< PIN4 );			
			output |= ((FullStep[i] & 0x8) >> 3) << PIN1;
			output |= ((FullStep[i] & 0x4) >> 2) << PIN2;
			output |= ((FullStep[i] & 0x2) >> 1) << PIN3;
			output |= ( FullStep[i] & 0x1) << PIN4;
			GPIOB->ODR = output; 
		}	
}

void GPIO_Motor_Init(void){	
	// Enable GPIO port B clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
	
	// Configure PB 2, PB 3, PB 6, and PB 7 as output
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOB->MODER = ~(3U<<(2*PIN1) | 3U<<(2*PIN2) | 3U<<(2*PIN3) | 3U<<(2*PIN4));  
	GPIOB->MODER |= 1U<<(2*PIN1) | 1U<<(2*PIN2) | 1U<<(2*PIN3) | 1U<<(2*PIN4);      //  Output(01)
	
	// Configure PB 2, PB 3, PB 6, and PB 7 to high speed
	// GPIO Speed: Low speed (00), Medium speed (01), Fast speed (10), High speed (11)
	GPIOB->OSPEEDR |= (3U<<(2*PIN1) | 3U<<(2*PIN2) | 3U<<(2*PIN3) | 3U<<(2*PIN4));
	
	// Configure PB 2, PB 3, PB 6, and PB 7 as push-pull
	// GPIO Output Type: Output push-pull (0), Output open drain (1) 
	GPIOB->OTYPER &= ~(1U<<PIN1 | 1U<<PIN2 | 1U<<PIN3 | 1U<<PIN4); // Push-pull
	
	// Configure PB 2, PB 3, PB 6, and PB 7 as no pull-up, no pull-down
	// GPIO Push-Pull: No pull-up, pull-down (00), Pull-up (01), Pull-down (10), Reserved (11)
	GPIOB->PUPDR  &= ~(3U<<(2*PIN1) | 3U<<(2*PIN2) | 3U<<(2*PIN3) | 3U<<(2*PIN4));  // No pull-up, no pull-down
}

int main(void){
	// Switch System Clock = 80 MHz
	System_Clock_Init();
	
	// Configure GPIO pins used by the stepper motor
	GPIO_Motor_Init();
	
	Full_Stepping();
}