#ifndef __STM32L476G_DISCOVERY_KEYPAD_H
#define __STM32L476G_DISCOVERY_KEYPAD_H

void Keypad_Init(void);
unsigned char Keypad_Scan(void);
void waitms(unsigned int ms);

#endif /* __STM32L476G_DISCOVERY_KEYPAD_H */
