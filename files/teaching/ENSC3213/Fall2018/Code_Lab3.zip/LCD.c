#include "lcd.h"
#include "stm32l476xx.h"
#include <stdint.h>

/* Constant table for number '0' --> '9' */
const uint16_t NumberMap[10] = {
        /* 0      1      2      3      4      5      6      7      8      9  */
        0x5F00,0x4200,0xF500,0x6700,0xEa00,0xAF00,0xBF00,0x04600,0xFF00,0xEF00
};

void LCD_DisplayChar(char character, uint8_t position){
  uint8_t digit[4]; /* Digit frame buffer */
   
  // Convert displayed character in segment in array digit 
  LCD_Conv_Char_Seg(character, digit);

  // Wait LCD Ready *
  while ((LCD->SR & LCD_SR_UDR) != 0); // Wait for Update Display Request Bit
  
  switch (position) {
    /* Position 1 on LCD (digit1)*/
    case 0:
			LCD->RAM[0] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
      LCD->RAM[2] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
      LCD->RAM[4] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
      LCD->RAM[6] &= ~( 1U << 4 | 1U << 23 | 1U << 22 | 1U << 3 );
			/* 1G 1B 1M 1E */
      LCD->RAM[0] |= ((digit[0] & 0x1) << 4) | (((digit[0] & 0x2) >> 1) << 23) | (((digit[0] & 0x4) >> 2) << 22) | (((digit[0] & 0x8) >> 3) << 3);
      /* 1F 1A 1C 1D  */
      LCD->RAM[2] |= ((digit[1] & 0x1) << 4) | (((digit[1] & 0x2) >> 1) << 23) | (((digit[1] & 0x4) >> 2) << 22) | (((digit[1] & 0x8) >> 3) << 3);
      /* 1Q 1K 1Col 1P  */
      LCD->RAM[4] |= ((digit[2] & 0x1) << 4) | (((digit[2] & 0x2) >> 1) << 23) | (((digit[2] & 0x4) >> 2) << 22) | (((digit[2] & 0x8) >> 3) << 3);
      /* 1H 1J 1DP 1N  */
      LCD->RAM[6] |= ((digit[3] & 0x1) << 4) | (((digit[3] & 0x2) >> 1) << 23) | (((digit[3] & 0x4) >> 2) << 22) | (((digit[3] & 0x8) >> 3) << 3);

			break;

    /* Position 2 on LCD (digit2)*/
    case 1:
			LCD->RAM[0] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
      LCD->RAM[2] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
      LCD->RAM[4] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
      LCD->RAM[6] &= ~( 1U << 6 | 1U << 13 | 1U << 12 | 1U << 5 );
			/* 2G 2B 2M 2E */
      LCD->RAM[0] |= ((digit[0] & 0x1) << 6) | (((digit[0] & 0x2) >> 1) << 13) | (((digit[0] & 0x4) >> 2) << 12) | (((digit[0] & 0x8) >> 3) << 5);
      /* 2F 2A 2C 2D  */
      LCD->RAM[2] |= ((digit[1] & 0x1) << 6) | (((digit[1] & 0x2) >> 1) << 13) | (((digit[1] & 0x4) >> 2) << 12) | (((digit[1] & 0x8) >> 3) << 5);
      /* 2Q 2K 2Col 2P  */
      LCD->RAM[4] |= ((digit[2] & 0x1) << 6) | (((digit[2] & 0x2) >> 1) << 13) | (((digit[2] & 0x4) >> 2) << 12) | (((digit[2] & 0x8) >> 3) << 5);
      /* 2H 2J 2DP 2N  */
      LCD->RAM[6] |= ((digit[3] & 0x1) << 6) | (((digit[3] & 0x2) >> 1) << 13) | (((digit[3] & 0x4) >> 2) << 12) | (((digit[3] & 0x8) >> 3) << 5);

			break;
    
    /* Position 3 on LCD (digit3)*/
    case 2:
			LCD->RAM[0] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
      LCD->RAM[2] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
      LCD->RAM[4] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
      LCD->RAM[6] &= ~( 1U << 15 | 1U << 29 | 1U << 28 | 1U << 14 );
			/* 3G 3B 3M 3E */
      LCD->RAM[0] |= ((digit[0] & 0x1) << 15) | (((digit[0] & 0x2) >> 1) << 29) | (((digit[0] & 0x4) >> 2) << 28) | (((digit[0] & 0x8) >> 3) << 14);
      /* 3F 3A 3C 3D */
      LCD->RAM[2] |= ((digit[1] & 0x1) << 15) | (((digit[1] & 0x2) >> 1) << 29) | (((digit[1] & 0x4) >> 2) << 28) | (((digit[1] & 0x8) >> 3) << 14);
      /* 3Q 3K 3Col 3P  */
      LCD->RAM[4] |= ((digit[2] & 0x1) << 15) | (((digit[2] & 0x2) >> 1) << 29) | (((digit[2] & 0x4) >> 2) << 28) | (((digit[2] & 0x8) >> 3) << 14);
      /* 3H 3J 3DP  3N  */
      LCD->RAM[6] |= ((digit[3] & 0x1) << 15) | (((digit[3] & 0x2) >> 1) << 29) | (((digit[3] & 0x4) >> 2) << 28) | (((digit[3] & 0x8) >> 3) << 14);

			break;
    
    /* Position 4 on LCD (digit4)*/
    case 3:
			LCD->RAM[0] &= ~( 1U << 31 | 1U << 30);
			LCD->RAM[1] &= ~( 1U << 1 | 1U << 0 );
      LCD->RAM[2] &= ~( 1U << 31 | 1U << 30);
			LCD->RAM[3] &= ~( 1U << 1 | 1U << 0 );
      LCD->RAM[4] &= ~( 1U << 31 | 1U << 30);
			LCD->RAM[5] &= ~( 1U << 1 | 1U << 0 );
      LCD->RAM[6] &= ~( 1U << 31 | 1U << 30);
			LCD->RAM[7] &= ~( 1U << 1 | 1U << 0 );
			/* 4G 4B 4M 4E */
      LCD->RAM[0] |= ((digit[0] & 0x1) << 31) | (((digit[0] & 0x8) >> 3) << 30);
			LCD->RAM[1] |= (((digit[0] & 0x2) >> 1) << 1) | (((digit[0] & 0x4) >> 2) << 0);
      /* 4F 4A 4C 4D */
      LCD->RAM[2] |= ((digit[1] & 0x1) << 31) | (((digit[1] & 0x8) >> 3) << 30);
			LCD->RAM[3] |= (((digit[1] & 0x2) >> 1) << 1) | (((digit[1] & 0x4) >> 2) << 0);
      /* 4Q 4K 4Col 4P  */
      LCD->RAM[4] |= ((digit[2] & 0x1) << 31) | (((digit[2] & 0x8) >> 3) << 30);
			LCD->RAM[5] |= (((digit[2] & 0x2) >> 1) << 1) | (((digit[2] & 0x4) >> 2) << 0);
      /* 4H 4J 4DP  4N  */
      LCD->RAM[6] |= ((digit[3] & 0x1) << 31) | (((digit[3] & 0x8) >> 3) << 30);
			LCD->RAM[7] |= (((digit[3] & 0x2) >> 1) << 1) | (((digit[3] & 0x4) >> 2) << 0);

			break;
    
    /* Position 5 on LCD (digit5)*/
    case 4:
			LCD->RAM[0] &= ~( 1U << 25 | 1U << 24);
			LCD->RAM[1] &= ~( 1U << 3 | 1U << 2 );
      LCD->RAM[2] &= ~( 1U << 25 | 1U << 24);
			LCD->RAM[3] &= ~( 1U << 3 | 1U << 2 );
      LCD->RAM[4] &= ~( 1U << 25 | 1U << 24 );
			LCD->RAM[5] &= ~( 1U << 3 | 1U << 2 );
      LCD->RAM[6] &= ~( 1U << 25 | 1U << 24 );
			LCD->RAM[7] &= ~( 1U << 3 | 1U << 2 );
			/* 5G 5B 5M 5E */
      LCD->RAM[0] |= (((digit[0] & 0x2) >> 1) << 25) | (((digit[0] & 0x4) >> 2) << 24);
			LCD->RAM[1] |= ((digit[0] & 0x1) << 3) | (((digit[0] & 0x8) >> 3) << 2);
      /* 5F 5A 5C 5D */
      LCD->RAM[2] |= (((digit[1] & 0x2) >> 1) << 25) | (((digit[1] & 0x4) >> 2) << 24);
			LCD->RAM[3] |= ((digit[1] & 0x1) << 3) | (((digit[1] & 0x8) >> 3) << 2);
      /* 5Q 5K 5Col 5P  */
      LCD->RAM[4] |= (((digit[2] & 0x2) >> 1) << 25) | (((digit[2] & 0x4) >> 2) << 24);
			LCD->RAM[5] |= ((digit[2] & 0x1) << 3) | (((digit[2] & 0x8) >> 3) << 2);
      /* 5H 5J 5DP  5N  */
      LCD->RAM[6] |= (((digit[3] & 0x2) >> 1) << 25) | (((digit[3] & 0x4) >> 2) << 24);
			LCD->RAM[7] |= ((digit[3] & 0x1) << 3) | (((digit[3] & 0x8) >> 3) << 2);

			break;
    
    /* Position 6 on LCD (digit6)*/
    case 5:
			LCD->RAM[0] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
      LCD->RAM[2] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
      LCD->RAM[4] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
      LCD->RAM[6] &= ~( 1U << 17 | 1U << 8 | 1U << 9 | 1U << 26 );
			/* 6G 6B 6M 6E */
      LCD->RAM[0] |= ((digit[0] & 0x1) << 17) | (((digit[0] & 0x2) >> 1) << 8) | (((digit[0] & 0x4) >> 2) << 9) | (((digit[0] & 0x8) >> 3) << 26);
      /* 6F 6A 6C 6D */
      LCD->RAM[2] |= ((digit[1] & 0x1) << 17) | (((digit[1] & 0x2) >> 1) << 8) | (((digit[1] & 0x4) >> 2) << 9) | (((digit[1] & 0x8) >> 3) << 26);
      /* 6Q 6K 6Col 6P  */
      LCD->RAM[4] |= ((digit[2] & 0x1) << 17) | (((digit[2] & 0x2) >> 1) << 8) | (((digit[2] & 0x4) >> 2) << 9) | (((digit[2] & 0x8) >> 3) << 26);
      /* 6H 6J 6DP  6N  */
      LCD->RAM[6] |= ((digit[3] & 0x1) << 17) | (((digit[3] & 0x2) >> 1) << 8) | (((digit[3] & 0x4) >> 2) << 9) | (((digit[3] & 0x8) >> 3) << 26);

			break;
  }
	
	LCD->SR |= LCD_SR_UDR; 								// Update display request. Cleared by hardware
	while ((LCD->SR & LCD_SR_UDD) == 0);	// Wait Until the LCD display is done  
}

void LCD_Initialization(void){
	LCD_PIN_Init();
	LCD_Clock_Init();	
	LCD_Configure();
	LCD_Clear();
}

void LCD_PIN_Init(void){	
	// Enable clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIODEN;
	
	//set as alternative function mode
	GPIOA->MODER &= ~GPIO_MODER_MODE6_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE7_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE8_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE9_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE10_0;
	GPIOA->MODER &= ~GPIO_MODER_MODE15_0;
	GPIOA->MODER |= GPIO_MODER_MODE6_1;
	GPIOA->MODER |= GPIO_MODER_MODE7_1;
	GPIOA->MODER |= GPIO_MODER_MODE8_1;
	GPIOA->MODER |= GPIO_MODER_MODE9_1;
	GPIOA->MODER |= GPIO_MODER_MODE10_1;
	GPIOA->MODER |= GPIO_MODER_MODE15_1;
	
	GPIOB->MODER &= ~GPIO_MODER_MODE0_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE1_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE4_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE5_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE9_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE12_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE13_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE14_0;
	GPIOB->MODER &= ~GPIO_MODER_MODE15_0;
	GPIOB->MODER |= GPIO_MODER_MODE0_1;
	GPIOB->MODER |= GPIO_MODER_MODE1_1;
	GPIOB->MODER |= GPIO_MODER_MODE4_1;
	GPIOB->MODER |= GPIO_MODER_MODE5_1;
	GPIOB->MODER |= GPIO_MODER_MODE9_1;
	GPIOB->MODER |= GPIO_MODER_MODE12_1;
	GPIOB->MODER |= GPIO_MODER_MODE13_1;
	GPIOB->MODER |= GPIO_MODER_MODE14_1;
	GPIOB->MODER |= GPIO_MODER_MODE15_1;
	
	GPIOC->MODER &= ~GPIO_MODER_MODE3_0;
	GPIOC->MODER &= ~GPIO_MODER_MODE4_0;
	GPIOC->MODER &= ~GPIO_MODER_MODE5_0;
	GPIOC->MODER &= ~GPIO_MODER_MODE6_0;
	GPIOC->MODER &= ~GPIO_MODER_MODE7_0;
	GPIOC->MODER &= ~GPIO_MODER_MODE8_0;
	GPIOC->MODER |= GPIO_MODER_MODE3_1;
	GPIOC->MODER |= GPIO_MODER_MODE4_1;
	GPIOC->MODER |= GPIO_MODER_MODE5_1;
	GPIOC->MODER |= GPIO_MODER_MODE6_1;
	GPIOC->MODER |= GPIO_MODER_MODE7_1;
	GPIOC->MODER |= GPIO_MODER_MODE8_1;
	
	GPIOD->MODER &= ~GPIO_MODER_MODE8_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE9_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE10_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE11_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE12_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE13_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE14_0;
	GPIOD->MODER &= ~GPIO_MODER_MODE15_0;
	GPIOD->MODER |= GPIO_MODER_MODE8_1;
	GPIOD->MODER |= GPIO_MODER_MODE9_1;
	GPIOD->MODER |= GPIO_MODER_MODE10_1;
	GPIOD->MODER |= GPIO_MODER_MODE11_1;
	GPIOD->MODER |= GPIO_MODER_MODE12_1;
	GPIOD->MODER |= GPIO_MODER_MODE13_1;
	GPIOD->MODER |= GPIO_MODER_MODE14_1;
	GPIOD->MODER |= GPIO_MODER_MODE15_1;
	
	//set each pin in alternative function register to 11
	GPIOA->AFR[0] |= GPIO_AFRL_AFSEL7;
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL7_2;
	GPIOA->AFR[0] |= GPIO_AFRL_AFSEL6;
	GPIOA->AFR[0] &= ~GPIO_AFRL_AFSEL6_2;
	GPIOA->AFR[1] |= GPIO_AFRH_AFSEL15;
	GPIOA->AFR[1] &= ~GPIO_AFRH_AFSEL15_2;
	GPIOA->AFR[1] |= GPIO_AFRH_AFSEL10;
	GPIOA->AFR[1] &= ~GPIO_AFRH_AFSEL10_2;
	GPIOA->AFR[1] |= GPIO_AFRH_AFSEL9;
	GPIOA->AFR[1] &= ~GPIO_AFRH_AFSEL9_2;
	GPIOA->AFR[1] |= GPIO_AFRH_AFSEL8;
	GPIOA->AFR[1] &= ~GPIO_AFRH_AFSEL8_2;
	

	GPIOB->AFR[0] |= GPIO_AFRL_AFSEL5;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL5_2;
	GPIOB->AFR[0] |= GPIO_AFRL_AFSEL4;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL4_2;
	GPIOB->AFR[0] |= GPIO_AFRL_AFSEL1;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL1_2;
	GPIOB->AFR[0] |= GPIO_AFRL_AFSEL0;
	GPIOB->AFR[0] &= ~GPIO_AFRL_AFSEL0_2;
	GPIOB->AFR[1] |= GPIO_AFRH_AFSEL15;
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL15_2;
	GPIOB->AFR[1] |= GPIO_AFRH_AFSEL14;
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL14_2;
	GPIOB->AFR[1] |= GPIO_AFRH_AFSEL13;
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL13_2;
	GPIOB->AFR[1] |= GPIO_AFRH_AFSEL12;
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL12_2;
	GPIOB->AFR[1] |= GPIO_AFRH_AFSEL9;
	GPIOB->AFR[1] &= ~GPIO_AFRH_AFSEL9_2;
	
	GPIOC->AFR[0] |= GPIO_AFRL_AFSEL7;
	GPIOC->AFR[0] &= ~GPIO_AFRL_AFSEL7_2;
	GPIOC->AFR[0] |= GPIO_AFRL_AFSEL6;
	GPIOC->AFR[0] &= ~GPIO_AFRL_AFSEL6_2;
	GPIOC->AFR[0] |= GPIO_AFRL_AFSEL5;
	GPIOC->AFR[0] &= ~GPIO_AFRL_AFSEL5_2;
	GPIOC->AFR[0] |= GPIO_AFRL_AFSEL4;
	GPIOC->AFR[0] &= ~GPIO_AFRL_AFSEL4_2;
	GPIOC->AFR[0] |= GPIO_AFRL_AFSEL3;
	GPIOC->AFR[0] &= ~GPIO_AFRL_AFSEL3_2;
	GPIOC->AFR[1] |= GPIO_AFRH_AFSEL8;
	GPIOC->AFR[1] &= ~GPIO_AFRH_AFSEL8_2;
	GPIOC->AFR[1] |= GPIO_AFRH_AFSEL8;
	GPIOC->AFR[1] &= ~GPIO_AFRH_AFSEL8_2;
	
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL15;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL15_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL14;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL14_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL13;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL13_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL12;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL12_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL11;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL11_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL10;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL10_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL9;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL9_2;
	GPIOD->AFR[1] |= GPIO_AFRH_AFSEL8;
	GPIOD->AFR[1] &= ~GPIO_AFRH_AFSEL8_2;	
}

void LCD_Clock_Init(void){
	// Enable write access to Backup domain
	if ( (RCC->APB1ENR1 & RCC_APB1ENR1_PWREN) == 0)
		RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;	// Power interface clock enable
	(void) RCC->APB1ENR1;  // Delay after an RCC peripheral clock enabling
	
	// Select LSE as RTC clock soucre 
	if ( (PWR->CR1 & PWR_CR1_DBP) == 0) {
		PWR->CR1  |= PWR_CR1_DBP;				  			// Enable write access to Backup domain
		while((PWR->CR1 & PWR_CR1_DBP) == 0);  	// Wait for Backup domain Write protection disable
	}
	
	// Reset LSEON and LSEBYP bits before configuring the LSE
	RCC->BDCR &= ~(RCC_BDCR_LSEON | RCC_BDCR_LSEBYP);

	// RTC Clock selection can be changed only if the Backup Domain is reset
	RCC->BDCR |=  RCC_BDCR_BDRST;
	RCC->BDCR &= ~RCC_BDCR_BDRST;
	
	// Note from STM32L4 Reference Manual: 	
  // RTC/LCD Clock:  (1) LSE is in the Backup domain. (2) HSE and LSI are not.	
	while((RCC->BDCR & RCC_BDCR_LSERDY) == 0){  // Wait until LSE clock ready
		RCC->BDCR |= RCC_BDCR_LSEON;
	}
	
	// Select LSE as RTC clock source
	// BDCR = Backup Domain Control Register 
	RCC->BDCR	&= ~RCC_BDCR_RTCSEL;	  // RTCSEL[1:0]: 00 = No Clock, 01 = LSE, 10 = LSI, 11 = HSE
	RCC->BDCR	|= RCC_BDCR_RTCSEL_0;   // Select LSE as RTC clock	
	
	RCC->APB1ENR1 &= ~RCC_APB1ENR1_PWREN;	// Power interface clock disable
	
	// Enable LCD peripheral Clock
	RCC->APB1ENR1 |= RCC_APB1ENR1_LCDEN;
}

void LCD_Configure(void){
	// set bias to 1/3
	LCD->CR |= LCD_CR_BIAS_1;
	LCD->CR &= ~LCD_CR_BIAS_0;
	//set duty to 1/4
	LCD->CR |= LCD_CR_DUTY;
	LCD->CR &= ~LCD_CR_DUTY_2;
	//set contrast to max
	LCD->FCR |= LCD_FCR_CC;
	//set pulse period to 7/ck_ps
	LCD->FCR |= LCD_FCR_PON;
	//disable mux_seg
	LCD->CR &= ~LCD_CR_MUX_SEG;
	//set voltage source to internal
	LCD->CR &= ~LCD_CR_VSEL;
	//wait for flag
	while((LCD->SR & LCD_SR_FCRSR) != LCD_SR_FCRSR);
	//enable lcd
	LCD->CR |= LCD_CR_LCDEN; 
	
	while((LCD->SR & LCD_SR_ENS ) != LCD_SR_ENS );
	while((LCD->SR & LCD_SR_RDY ) != LCD_SR_RDY );
}

void LCD_Clear(void){
  uint8_t counter = 0;

  // Wait until LCD ready */  
	while ((LCD->SR & LCD_SR_UDR) != 0) {} // Wait for Update Display Request Bit
  
  for (counter = 0; counter <= 15; counter++) {
    LCD->RAM[counter] = 0;
  }

  /* Update the LCD display */
	LCD->SR |= LCD_SR_UDR; 
}

static void LCD_Conv_Char_Seg(char c, uint8_t* digit) {
  uint16_t ch = 0 ;
  uint8_t loop, index;
	
	ch = NumberMap[c-0x30];

	for (loop = 12, index = 0; index < 4; loop -= 4, index++)
  {
    digit[index] = (ch >> loop) & 0x0F; /*To isolate the less significant digit */
  }
}
