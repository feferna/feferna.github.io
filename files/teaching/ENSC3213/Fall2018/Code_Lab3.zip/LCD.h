#ifndef __STM32L476G_DISCOVERY_LCD_H
#define __STM32L476G_DISCOVERY_LCD_H

#include <stdint.h>

void LCD_DisplayChar(char character, uint8_t digit_position);
void LCD_Initialization(void);
void LCD_Clock_Init(void);
void LCD_PIN_Init(void);
void LCD_Configure(void);
void LCD_Clear(void);
static void LCD_Conv_Char_Seg(char c, uint8_t* digit);

#endif /* __STM32L476G_DISCOVERY_LCD_H */
