#include "Keypad.h"
#include "stm32l476xx.h"
#include <stdint.h>

void Keypad_Init(void){	
	// Enable GPIO clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOEEN;	
	
	// Setting PA 1, 2, 3, 5 as GPIO input
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOA->MODER &= ~(GPIO_MODER_MODE1 | GPIO_MODER_MODE2 | GPIO_MODER_MODE3 | GPIO_MODER_MODE5); // GPIO input
	
	// Setting PE 10, 11, 12, 13 as GPIO output
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOE->MODER &= ~(GPIO_MODER_MODE10 | GPIO_MODER_MODE11 | GPIO_MODER_MODE12 | GPIO_MODER_MODE13);
	GPIOE->MODER |= (GPIO_MODER_MODE10_0 | GPIO_MODER_MODE11_0 | GPIO_MODER_MODE12_0 | GPIO_MODER_MODE13_0);  // GPIO output

	// GPIO Output Type: Output push-pull (0, reset), Output open drain (1) 
	GPIOE->OTYPER |= (GPIO_IDR_ID10 | GPIO_IDR_ID11 | GPIO_IDR_ID12 | GPIO_IDR_ID13);
}

unsigned char Keypad_Scan(void){

	unsigned char row, col;
	unsigned char key;
	
	unsigned char keymap[4][4] = {
		{'1','2','3','*'},
		{'4','5','6','*'},
		{'7','8','9','*'},
		{'*','0','*','*'}
	};
	
	uint32_t inputMask  = GPIO_IDR_ID1 | GPIO_IDR_ID2 | GPIO_IDR_ID3 | GPIO_IDR_ID5;
	uint32_t outputs[4] = {GPIO_ODR_OD10, GPIO_ODR_OD11, GPIO_ODR_OD12, GPIO_ODR_OD13};
	uint32_t inputs[4]  = {GPIO_IDR_ID1, GPIO_IDR_ID2, GPIO_IDR_ID3, GPIO_IDR_ID5};
	
	GPIOE->ODR &= ~(GPIO_ODR_OD10 | GPIO_ODR_OD11 | GPIO_ODR_OD12 | GPIO_ODR_OD13);
	waitms(3); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5 	
	while( (GPIOA->IDR & inputMask) == inputMask){;}  // Wait until key pressed
		
	for(row = 0; row < 4; row++){ // Row scan
		GPIOE->ODR |= (GPIO_ODR_OD10 | GPIO_ODR_OD11 | GPIO_ODR_OD12 | GPIO_ODR_OD13);
		GPIOE->ODR &= ~outputs[row];
		waitms(3); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5 
		for(col = 0; col < 4; col++){// Column scan 			
			if((GPIOA->IDR & inputs[col]) == 0 ){
				key = keymap[row][col];
				while( (GPIOA->IDR & inputMask) != inputMask){;} // Wait until key released
				return key;
			}
		}
	}
	
	return 0xFF;
}


void waitms(unsigned int ms){
	int i, j;
	for(i = 0; i < ms; i++){
		for(j=0; j < 4000; j++);
	}	
}
