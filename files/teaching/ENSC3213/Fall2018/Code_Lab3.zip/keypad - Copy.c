#include "Keypad.h"
#include "stm32l476xx.h"
#include <stdint.h>

void Keypad_Init(void){	
	// Enable GPIO clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN | RCC_AHB2ENR_GPIOEEN;	
	
	// Setting PA 1, 2, 3, 5 as GPIO input
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOA->MODER &= ~(GPIO_MODER_MODE1 | GPIO_MODER_MODE2 | GPIO_MODER_MODE3 | GPIO_MODER_MODE5); // GPIO input
	
	// Setting PE 10, 11, 12, 13 as GPIO output
	// GPIO Mode: Input(00), Output(01), AlterFunc(10), Analog(11, reset)
	GPIOE->MODER &= ~(GPIO_MODER_MODE10 | GPIO_MODER_MODE11 | GPIO_MODER_MODE12 | GPIO_MODER_MODE13);
	GPIOE->MODER |= (GPIO_MODER_MODE10_0 | GPIO_MODER_MODE11_0 | GPIO_MODER_MODE12_0 | GPIO_MODER_MODE13_0);  // GPIO output

	// GPIO Output Type: Output push-pull (0, reset), Output open drain (1) 
	GPIOE->OTYPER |= (GPIO_IDR_ID10 | GPIO_IDR_ID11 | GPIO_IDR_ID12 | GPIO_IDR_ID13);
}

unsigned char Keypad_Scan(void){
	
	// 1) Create a look up table where the row and column from the scanning algorithm can be converted to a number
	unsigned char keymap[4][4] = {
		{'1','2','3','A'},
		{'4','5','6','B'},
		{'7','8','9','C'},
		{'*','0','#','D'}
	};
	
	// Before the for-loops, we should clear all GPIOE outputs corresponding with the keypad's rows.
	GPIOE->ODR &= ~(GPIO_ODR_OD10 | GPIO_ODR_OD11 | GPIO_ODR_OD12 | GPIO_ODR_OD13);
	
	
	waitms(3); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5
	
	// 2) Wait until any key is pressed.
	//    You can use an empty while loop to do this.
	//    You have to compare the GPIOA->IDR with a mask to verify if PA1, PA2, PA3 or PA5 was pressed.
	
	while((GPIOA->IDR & (GPIO_IDR_ID1 | GPIO_IDR_ID2 | GPIO_IDR_ID3 | GPIO_IDR_ID5)) == (GPIO_IDR_ID1 | GPIO_IDR_ID2 | GPIO_IDR_ID3 | GPIO_IDR_ID5)){;}  // Wait until key pressed	
	
	// Create variables to help you coding...
	
	// Variables used in the for-loop
	unsigned int row, col;
	
	// Arrays to help with the scan algorithm
	// The first array is related to row scan (GPIOE). 
	// We first create an array with four masks where each mask contains a single '1' in the location you want the row to be zero.
	// These masks should contains '1's because we are going to clear that position. Therefore, the final output will be a zero.
	uint32_t outputs[4] = {GPIO_ODR_OD10, GPIO_ODR_OD11, GPIO_ODR_OD12, GPIO_ODR_OD13};
	
	// Now, we should create an array with four masks used to read the inputs from GPIOA (a.k.a. the columns of the keypad)
	// These masks should also contain a single '1' corresponding to each column of the keypad.
	// In other words, this array will be used to verify which column was pressed.
	uint32_t inputs[4]  = {GPIO_IDR_ID1, GPIO_IDR_ID2, GPIO_IDR_ID3, GPIO_IDR_ID5};
	
	// 3) Your first "for-loop" (row scan)!
	//    Loop over the number of rows in the keypad (4 rows).
	//    Note: you can use integers in both "for-loops".
	
	for(row = 0; row < 4; row++){
		// 3.1) Inside the first for loop, you have to set all rows output to 1 (GPIOE).
		// 3.2) For every iteration, clear (put a zero) the corresponding row on GPIOE.
		GPIOE->ODR |= (GPIO_ODR_OD10 | GPIO_ODR_OD11 | GPIO_ODR_OD12 | GPIO_ODR_OD13); // Set all rows to 1
		GPIOE->ODR &= ~outputs[row]; // Loop over the output array to clear each row in each step of the for-loop
		
		waitms(3); // Delay is needed due to the capacitors connected to pin PA 1, 2, 3, 5
		
		// 4) Your second "for-loop" (column scan)!
		//    Loop over the number of columns in the keypad (4 rows).
		for(col = 0; col < 4; col++){// Column scan 			
			// 4.1) Use an IF statement to verify which GPIOA->IDR was set to zero.
			// 4.2) Use the above lookup table to return the pressed key.
			// 4.3) You should put a empty while-loop inside your IF statement
			//      to wait the key to be released.
			if((GPIOA->IDR & some_mask) == some_value ){
				while( (GPIOA->IDR & some_mask) != some_mask){;} // Wait until key released
				return keymap[row][col];
			}
		}
	}
	
	return 0xFF;
}


void waitms(unsigned int ms){
	int i, j;
	for(i = 0; i < ms; i++){
		for(j=0; j < 4000; j++);
	}	
}