#include "stm32l476xx.h"
#include "lcd.h"
#include "keypad.h"


void System_Clock_Init(void);

int main(void){
	char keypad_digit;
	int digit_position = 0;
	
	System_Clock_Init();
	LCD_Initialization();
	LCD_Clear();
	Keypad_Init();

	while(1) {
		keypad_digit = Keypad_Scan();
		
		if (keypad_digit != '*') {
			LCD_DisplayChar(keypad_digit, digit_position);
			digit_position++;
		}
		
		if (digit_position > 6) {
			LCD_Clear();
			digit_position = 0;
		}
	}
}

void System_Clock_Init(void){
	
	// Enable High Speed Internal Clock (HSI = 16 MHz)
  RCC->CR |= ((uint32_t)RCC_CR_HSION);
	
  // wait until HSI is ready
  while ( (RCC->CR & (uint32_t) RCC_CR_HSIRDY) == 0 );
	
  // Select HSI as system clock source 
  RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
  RCC->CFGR |= (uint32_t)RCC_CFGR_SW_HSI;  //01: HSI16 oscillator used as system clock

  // Wait till HSI is used as system clock source 
  while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) == 0 );		
}
