#include "lcd.h"
#include "stm32l476xx.h"

////////////////////////////////////////////////////////
// You are required to complete the following functions
////////////////////////////////////////////////////////

void LCD_PIN_Init(void){
	// Complete the LCD_PIN_Init() function by the end of class.
	// Due on Sept. 24, 2018 - This function is worth 10 points towards your lab 2 grade
	
	// Enable the clock of GPIO port A, B, C and D
	RCC->AHB2ENR |= MASK;
	
	// GPIO Mode: Input(00, reset), Output(01), AlterFunc(10), Analog(11, reset)
	// GPIO Speed: Low speed (00), Medium speed (01), Fast speed (10), High speed (11)
	// GPIO Push-Pull: No pull-up, pull-down (00), Pull-up (01), Pull-down (10), Reserved (11)
	// GPIO Output Type: Output push-pull (0, reset), Output open drain (1)
	
    // Configure PA 6, 7, 8, 9, 10, 15 as Alternative Function 11 (0x0B)
	GPIOA->MODER &= ~(MASK);
	GPIOA->MODER |=  MASK;
	
	GPIOA->AFR[0] &= ~MASK;
	GPIOA->AFR[0] |= MASK;
	
	GPIOA->AFR[1] &= ~MASK;
	GPIOA->AFR[1] |= MASK;
	
	GPIOA->OSPEEDR &= ~(MASK);
	
	// GPIOA Push-Pull: No pull-up, pull-down (00)
	GPIOA->PUPDR &= ~MASK;
  
	// Configure PB 0, 1, 4, 5, 9, 12, 13, 14, 15 as Alternative Function 11 (0x0B)
	GPIOB->MODER &= ~(MASK);
	GPIOB->MODER |=  MASK;
	
	GPIOB->AFR[0] &= ~MASK;
	GPIOB->AFR[0] |= MASK;
	
	GPIOB->AFR[1] &= ~MASK;
	GPIOB->AFR[1] |= MASK;
	
	GPIOB->OSPEEDR &= ~(MASK);
	
	// GPIOB Push-Pull: No pull-up, pull-down (00)
	GPIOB->PUPDR &= ~MASK;

	
    // Configure PC 3, 4, 5, 6, 7, 8 as Alternative Function 11 (0x0B)
	GPIOC->MODER &= ~(MASK);
	GPIOC->MODER |=  MASK;
	
	GPIOC->AFR[0] &= ~MASK;
	GPIOC->AFR[0] |= MASK;
	
	GPIOC->AFR[1] &= ~MASK;
	GPIOC->AFR[1] |= MASK;
	
	GPIOC->OSPEEDR &= ~(MASK);
	
	// GPIOC Push-Pull: No pull-up, pull-down (00)
	GPIOC->PUPDR &= ~MASK;

	
	// Configure PD 8, 9, 10, 11, 12, 13, 14, 15 as Alternative Function 11 (0x0B)
	GPIOD->MODER &= ~(MASK);
	GPIOD->MODER |=  MASK;
	
	GPIOD->AFR[0] &= ~MASK;
	GPIOD->AFR[0] |= MASK;
	
	GPIOD->AFR[1] &= ~MASK;
	GPIOD->AFR[1] |= MASK;
	
	GPIOD->OSPEEDR &= ~(MASK);
	
	// GPIOD Push-Pull: No pull-up, pull-down (00)
	GPIOD->PUPDR &= ~MASK;	
}

void LCD_Configure(void){
	// Complete the LCD_Configure() function by the end of class.
	// Due on Oct. 01, 2018 - This function is worth 30 points towards your lab 2 grade
	
	// For each of the lines below, set or clear the correct bits in the CR and FCR registers.
	// The bit position can be found using the LCD Register Map and Pre-Lab 2, Question 5.
	
	// 1. Configure BIAS[1:0] bits of register LCD_SR and set the bias to 1/3
	LCD->CR ; //BIAS[1:0]: 00=1/4; 01=1/2; 10=1/3
	
	// 2. Configure DUTY[2:0] bits of LCD_CR and set the duty to 1/4
	LCD->CR ; //DUTY[2:0]: 000=Static; 001=1/2; 010=1/3; 011=1/4; 100=1/8
	
	// 3. Configure CC[2:0] bits of LCD_FCR and set the contrast to max value 111
	LCD->FCR ;
	
	// 4. Configure PON[2:0] bits of LCD_FCR and set the pulse on period to 111.
	LCD->FCR ;     // PON[2:0] = 0x111
	
	// 5. Diable the MUX_SEG segment of LCD_CR
	LCD->CR ;
	
	// 6. Select internal voltage as LCD voltage source
	LCD->CR ; // 0 = internal source, 1 = external source (VLCD pin)
	
	// 7. Wait until FCRSF flag of LCD_SR is set
	while ((LCD->SR & MASK) == 0); // Wait until FCRSF flag is set
	
	// 8. Enable the LCD by setting LCDEN bit of LCD_CR
	LCD->CR ;
	
	// 9. Wait until the LCD is enabled by checking the ENS bit of LCD_SR
	while ((LCD->SR & MASK) == 0); // ENS is set by hardware automatically
	
	// 10. Wait until the LCD booster is ready by checking the RDY bit of LCD_SR
	while ((LCD->SR & MASK) == 0); // Loop until step-up converter is ready to provide the correct voltage.
}

void LCD_Display_Name(void){
	// Complete the LCD_Display_Name() function by the end of class.
	// Due on Oct. 08, 2018 - This function is worth 20 points towards your lab 2 grade
	// Don't forget to answer the lab demo questions to T.A.! These questions are worth 10 points towards your lab 2 grade.
	
	// Is the LCD_RAM protected?
	// If the UDR bit in LCD_SR is set, then RAM is protected
	while ((LCD->SR & MASK) != 0); // Wait for Update Display Request Bit
	
	// Set up the value of LCD_RAM[0-7] with your last name
	LCD->RAM[0] ;
	LCD->RAM[1] ;
	LCD->RAM[2] ;
	LCD->RAM[3] ;
	LCD->RAM[4] ;
	LCD->RAM[5] ;
	LCD->RAM[6] ;
	LCD->RAM[7] ;
	
	// Set the UDR flag of LCD_SR register to request update display
	LCD->SR |= MASK;
	
	// Is the update done?
	// If the UDD bit in LCD_SR is set, then update is done.	
	while ((LCD->SR & MASK) == 0); // Wait for update display done
}

///////////////////////////////////////////
// Do not change the codes below
///////////////////////////////////////////

void LCD_Clock_Init(void){
	// Enable write access to Backup domain
	if ( (RCC->APB1ENR1 & RCC_APB1ENR1_PWREN) == 0)
		RCC->APB1ENR1 |= RCC_APB1ENR1_PWREN;	// Power interface clock enable
	(void) RCC->APB1ENR1;  // Delay after an RCC peripheral clock enabling
	
	// Select LSE as RTC clock soucre 
	if ( (PWR->CR1 & PWR_CR1_DBP) == 0) {
		PWR->CR1  |= PWR_CR1_DBP;				  			// Enable write access to Backup domain
		while((PWR->CR1 & PWR_CR1_DBP) == 0);  	// Wait for Backup domain Write protection disable
	}
	
	// Reset LSEON and LSEBYP bits before configuring the LSE
	RCC->BDCR &= ~(RCC_BDCR_LSEON | RCC_BDCR_LSEBYP);

	// RTC Clock selection can be changed only if the Backup Domain is reset
	RCC->BDCR |=  RCC_BDCR_BDRST;
	RCC->BDCR &= ~RCC_BDCR_BDRST;
	
	// Note from STM32L4 Reference Manual: 	
  // RTC/LCD Clock:  (1) LSE is in the Backup domain. (2) HSE and LSI are not.	
	while((RCC->BDCR & RCC_BDCR_LSERDY) == 0){  // Wait until LSE clock ready
		RCC->BDCR |= RCC_BDCR_LSEON;
	}
	
	// Select LSE as RTC clock source
	// BDCR = Backup Domain Control Register 
	RCC->BDCR	&= ~RCC_BDCR_RTCSEL;	  // RTCSEL[1:0]: 00 = No Clock, 01 = LSE, 10 = LSI, 11 = HSE
	RCC->BDCR	|= RCC_BDCR_RTCSEL_0;   // Select LSE as RTC clock	
	RCC->BDCR |= RCC_BDCR_RTCEN;      // Enable RTC clock to enable accesses to BDCR
	
	RCC->APB1ENR1 &= ~RCC_APB1ENR1_PWREN;	// Power interface clock disable
	
	// Wait for the external capacitor Cext which is connected to the VLCD pin is charged (approximately 2ms for Cext=1uF) 
	
	// Enable LCD peripheral Clock
	RCC->APB1ENR1 |= RCC_APB1ENR1_LCDEN;
}