/* Standard STM32L476xxx driver headers */
#include "stm32l476xx.h"

//********************************************************
// @file    main.c
// @modifier  Francisco Erivaldo Fernandes Junior
// @version V1.0
// @date    Aug-21-2018
// @note    
// @brief   C code for STM32L4 Discovery Kit
// @note
//          This code is for LAB 1
//********************************************************

//************************************************************************************
// Use this function if you want to use PLL clock with 80 MHz.
// It is not necessary to use a clock of 80 MHz when we just playing with some LEDs.
//************************************************************************************
/*
void System_Clock_Init(void) {
	
	// Set-up the FLASH memory latency to one wait state
	// Otherwise, the PLL clock will not lock.
	FLASH->ACR &= ~FLASH_ACR_LATENCY;
	FLASH->ACR |= FLASH_ACR_LATENCY_1WS;
	
	// Enable the Internal High Speed oscillator (HSI)
  RCC->CR |= RCC_CR_HSION;
  while((RCC->CR & RCC_CR_HSIRDY) == 0);

  RCC->CR &= ~RCC_CR_PLLON; 
  while((RCC->CR & RCC_CR_PLLRDY) == RCC_CR_PLLRDY);
	
  // Select clock source to PLL
  RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLSRC;
  RCC->PLLCFGR |= RCC_PLLCFGR_PLLSRC_HSI; // 00 = No clock, 01 = MSI, 10 = HSI, 11 = HSE
	
  // Make PLL as 80 MHz
  // f(VCO clock) = f(PLL clock input) * (PLLN / PLLM) = 16MHz * 20/2 = 160 MHz
  // f(PLL_R) = f(VCO clock) / PLLR = 160MHz/2 = 80MHz
  RCC->PLLCFGR = (RCC->PLLCFGR & ~RCC_PLLCFGR_PLLN) | 20U << 8;
  RCC->PLLCFGR = (RCC->PLLCFGR & ~RCC_PLLCFGR_PLLM) | 1U << 4; 
  RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLR;  // 00: PLLR = 2, 01: PLLR = 4, 10: PLLR = 6, 11: PLLR = 8
  RCC->PLLCFGR |= RCC_PLLCFGR_PLLREN; // Enable Main PLL PLLCLK output 
  RCC->CR |= RCC_CR_PLLON; 
  while((RCC->CR & RCC_CR_PLLRDY) == 0);
	
  // Select PLL selected as system clock
  RCC->CFGR &= ~RCC_CFGR_SW;
  RCC->CFGR |= RCC_CFGR_SW_PLL; // 00: MSI, 01:HSI, 10: HSE, 11: PLL
	
  // Wait until System Clock has been selected
  while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}
*/
//**********************************************************************************************

// This function will use the High Speed Internal Clock with a frequency of 16 MHz
void System_Clock_Init(void) {
	//See STM32L476VGT6 Reference Manual, 
	//Section 8.4 for more details about the RCC registers.
	
		// Enable High Speed Internal Clock (HSI = 16 MHz)
  RCC->CR |= ((uint32_t)RCC_CR_HSION);
	
  // wait until HSI is ready
  while ( (RCC->CR & (uint32_t) RCC_CR_HSIRDY) == 0 ) {;}
	
  // Select HSI as system clock source 
  RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
  RCC->CFGR |= (uint32_t)RCC_CFGR_SW_HSI;  //01: HSI16 oscillator used as system clock

  // Wait till HSI is used as system clock source 
  while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) == 0 ) {;}
}

void GPIO_Clock_Enable(){
	// Enable GPIO A, B and E
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; 
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN; 
}

void GPIO_Pin_Init(){
	// Configure PA0 (Center), PA1 (Left), PA2 (Right), PA3 (Up), and PA5 (Down) as Input
	GPIOA->MODER &= ~GPIO_MODER_MODE0; // Clear GPIOA_MODER bits 0 and 1 (PA0 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE1; // Clear GPIOA_MODER bits 3 and 2 (PA1 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE2; // Clear GPIOA_MODER bits 5 and 4 (PA2 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE3; // Clear GPIOA_MODER bits 7 and 6 (PA3 as input)
	GPIOA->MODER &= ~GPIO_MODER_MODE5; // Clear GPIOA_MODER bits 11 and 10 (PA5 as input)
	
	// Another solution would be to use just one mask
	// GPIOA->MODER &= ~(GPIO_MODER_MODE0 | GPIO_MODER_MODE1 | PIO_MODER_MODE2  | GPIO_MODER_MODE3 | GPIO_MODER_MODE5);
	// GPIOA->MODER &= ~(0xCFF);
	
	// Configure PA0 (Center), PA1 (Left), PA2 (Right), PA3 (Up), and PA5 (Down) as Pulldown
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD0;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD0_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD1;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD1_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD2;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD2_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD3;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD3_1;
	
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD5;
	GPIOA->PUPDR |= GPIO_PUPDR_PUPD5_1;
	
	// Alternative solution:
	// GPIOA->PUPDR &= ~(GPIO_PUPDR_PUPD0 | GPIO_PUPDR_PUPD1 | GPIO_PUPDR_PUPD2 | GPIO_PUPDR_PUPD3 | GPIO_PUPDR_PUPD5);
	// GPIOA->PUPDR |= (GPIO_PUPDR_PUPD0_1 | GPIO_PUPDR_PUPD1_1 | GPIO_PUPDR_PUPD2_1 | GPIO_PUPDR_PUPD3_1 | GPIO_PUPDR_PUPD5_1);
	
	// Another solution would be to use just one mask
	// GPIOA->PUPDR &= ~0xCFF
	// GPIOA->PUPDR |= 0x8AA
	
	// Configure PB2 (Red LED) as Output
	GPIOB->MODER &= ~GPIO_MODER_MODE2;
	GPIOB->MODER |= GPIO_MODER_MODE2_0;
	
	// Alternative solution:
	// GPIOB->MODER &= ~0x03<<4;
	// GPIOB->MODER |= 1<<4;
	
	// Configure PE8 (Green LED) as Output
	GPIOE->MODER &= ~GPIO_MODER_MODE8;
	GPIOE->MODER |= GPIO_MODER_MODE8_0;
	
	// Alternative solution:
	// GPIOB->MODER &= ~0x03<<16;
	// GPIOB->MODER |= 1<<16;
	
	// Configure PB2 (Red LED) Output Type as Push-Pull
	GPIOB->OTYPER &= ~GPIO_OTYPER_OT2;
	
	// Configure PE8 (Green LED) Output Type as Push-Pull
	GPIOE->OTYPER &= ~GPIO_OTYPER_OT8;
	
	// Alternative solution:
	// GPIOB->OTYPE &= ~(1<<2);
	// GPIOE->OTYPE &= ~(1<<8);
	
	// Set the speed for PB2 and PE8 as low
	GPIOB->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED2;
	GPIOE->OSPEEDR &= ~GPIO_OSPEEDR_OSPEED8;
	
	// Alternative solution:
	// GPIOB->OSPEEDR &= ~(0x03<<4);
	// GPIOE->OSPEEDR &= ~(0x03<<16);
	
	// Configure PB2 (Red LED) Output Type as No Pull-up No Pull-down
	GPIOB->PUPDR &= ~GPIO_PUPDR_PUPD2;
	
	// Configure PE8 (Green LED) Output Type as No Pull-up No Pull-down
	GPIOE->PUPDR &= ~GPIO_PUPDR_PUPD8;
	
	// Alternative solution:
	// GPIOB->PUPDR &= ~(0x03<<4);
	// GPIOE->PUPDR &= ~(0x03<<16);
}

//******************************************************************************************
//* The main program starts here
//******************************************************************************************

int main(void) {
	System_Clock_Init();
	
	GPIO_Clock_Enable();
	
	GPIO_Pin_Init();
	
	// Begin infinite loop
	while(1) {
		// Set both LEDs to on when up button is pushed
		// Toggle both LEDs when middle button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID0) != 0x00){
			GPIOE->ODR ^= GPIO_ODR_ODR_8;
			GPIOB->ODR ^= GPIO_ODR_ODR_2;
			while((GPIOA->IDR & GPIO_IDR_ID0) != 0x00);
		}
		
		// Toggle red LED when right button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID2) != 0x00){
			GPIOB->ODR ^= GPIO_ODR_ODR_2;
			while((GPIOA->IDR & GPIO_IDR_ID2) != 0x00);
		}
		
		// Toggle green LED when left button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID1) != 0x00){
			GPIOE->ODR ^= GPIO_ODR_ODR_8;
			while((GPIOA->IDR & GPIO_IDR_ID1) != 0x00);
		}
		
		// Set both LEDs to on when up button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID3) != 0x00){
			GPIOE->ODR |= 0x100;
			GPIOB->ODR |= 0x04;
			while((GPIOA->IDR & GPIO_IDR_ID3) != 0x00);
		}
		
		// Set both LEDs to off when down button is pushed
		if((GPIOA->IDR & GPIO_IDR_ID5) != 0x00){
			GPIOE->ODR &= ~0x100;
			GPIOB->ODR &= ~0x04;
			while((GPIOA->IDR & GPIO_IDR_ID5) != 0x00);
		}
	}
}
